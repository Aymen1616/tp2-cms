
<?php
get_header();
?>

<div class="wysiwyg">
    <?php echo get_field('apropos_editeur'); ?>
</div>

<?php
get_footer();
?>
